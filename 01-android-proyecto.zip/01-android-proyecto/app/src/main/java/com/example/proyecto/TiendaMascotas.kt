package com.example.proyecto

class TiendaMascotas(var id:Int?,
                     var nombre:String,
                     var direccion:String,
                     var telefono:String,
                     var latitud: String,
                     var longitud: String
){
}