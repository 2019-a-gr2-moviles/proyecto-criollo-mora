package com.example.proyecto

class Persona(var id:Int?,
              var nombre:String,
              var apellido:String,
              var cedula:String,
              var fechaNac:String
              ){
}