package com.example.proyecto

class RazaPerro(var id:Int?,
                var nombreRaza:String//,
                //var perroDeRaza: ArrayList<Perro>?
){
}