package com.example.proyecto

class Usuario(var id:Int?, var username:String, var password:String?/*,
              var tipo:String?*/) {
}