package com.example.proyecto

class Perro(var id:Int?,
            var sexo:String,
            var edad:String,
            var color:String,
            /*var idRaza:RazaPerro?,
            var idPersona:Persona?,
            var idTienda:TiendaMascotas?*/
            var idRaza:Int?,
            var idPersona:Int?,
            var idTienda:Int?

){
}